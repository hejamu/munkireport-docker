<?php

namespace Tests;

abstract class TestCase
{
}
