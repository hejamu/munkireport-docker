# Certificates

Use this folder to store certificates for SAML authentication

These certs are used:

`sp.crt` - the certificate of the service provider.
`sp.key` - the private key of the service provider.
`idp.crt` - the certificate to validate the response from the identity provider.

