<?php

define('PUBLIC_ROOT', dirname(__FILE__) . '/' );
define('APP_ROOT', dirname(PUBLIC_ROOT) . '/' );


require_once __DIR__ . '/../bootstrap/app.php';
