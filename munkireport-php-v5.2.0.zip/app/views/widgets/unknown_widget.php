<div class="col-md-6">

	<div class="panel panel-default" id="unknown-widget">

		<div class="panel-heading">

			<h3 class="panel-title"><i class="fa fa-question-circle"></i> <span data-i18n="widget.unknown.title"></span></h3>
		
		</div>

		<div class="panel-body">
			
            <div class="alert alert-danger" role="alert">
                <strong><?=$widgetName?></strong> <span data-i18n="widget.unknown.alert"></span>
            </div>


		</div>

	</div><!-- /panel -->

</div><!-- /col-lg-4 -->
