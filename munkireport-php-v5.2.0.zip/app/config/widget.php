<?php

return [
    'search_paths' => env('WIDGET_SEARCH_PATHS', [local_conf('views/widgets')]),
];
