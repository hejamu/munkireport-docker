<?php

return [
    'search_paths' => env('AUTH_LOCAL_SEARCH_PATHS', [local_conf('users')]),
];
